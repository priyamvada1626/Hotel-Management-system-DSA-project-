
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import net.proteanit.sql.*;


/**
 *
 * @author raani
 */
public class IssueBox extends JFrame  implements ActionListener{
    
    JTextField tfissue;
    JButton back,submit;
    JLabel roomnumber;
    private String username;
    private String password;
    
    IssueBox(String usern, String passw){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel heading = new JLabel("Issue Box");
        heading.setFont(new Font("Tahoma",Font.PLAIN,20));
        heading.setBounds(150,20,200,20);
        add(heading);
        
        JLabel lblroom = new JLabel("Room Number");
        lblroom.setBounds(30,70,150,20);
        add(lblroom);
        
        roomnumber = new JLabel();
        roomnumber.setBounds(190,70,150,20);
        add(roomnumber);
        
        JLabel lblissue = new JLabel("Any issues write here ");
        lblissue.setBounds(30,130,150,20);
        add(lblissue);
        
        tfissue = new JTextField();
        tfissue.setBounds(180, 130, 250, 25);
        add(tfissue);
        
        this.username = usern;
        this.password = passw;
        
        try {
            Conn c = new Conn();
            
            ResultSet rs = c.s.executeQuery("select * from userlogin where username = '"+usern+"' and password = '"+passw+"'");
            
            while(rs.next()){
                roomnumber.setText(rs.getString("room_allocated"));
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        submit = new JButton("Submit");
        submit.setForeground(Color.BLACK);
        submit.setBackground(Color.WHITE);
        submit.setBounds(100,180,100,30);
        submit.addActionListener(this);
        add(submit);
        
        back = new JButton("Back");
        back.setForeground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.setBounds(250,180,100,30);
        back.addActionListener(this);
        add(back);
        
        setBounds(400,200,450,250);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == submit){
            
            try {
                Conn c = new Conn();
                
                String room_num = roomnumber.getText();
                String issue = tfissue.getText();
                
                String query = "insert into issuebox values('"+room_num+"','"+issue+"','ongoing')";
                
                c.s.executeUpdate(query); 
                
                JOptionPane.showMessageDialog(null,"Issue Added Successfully");
            
            }catch(Exception e){
                e.printStackTrace();
            }
        }else if(ae.getSource() == back){
            setVisible(false);
            new UserDashboard(username, password);
        }
    }
    
    public static void main(String[] args){
    }
}
