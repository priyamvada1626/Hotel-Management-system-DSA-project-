
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author raani
 */
public class NearBy extends JFrame implements ActionListener{
    
    JButton restraurants,outingplaces,shoping,entertainment,back;
    private String username;
    private String password;
            
    NearBy(String usern, String passw){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        this.username = usern;
        this.password = passw;
        
        JLabel heading = new JLabel("NearBy Locations");
        heading.setFont(new Font("Tahoma",Font.PLAIN,20));
        heading.setBounds(130,20,200,20);
        add(heading);
        
        restraurants = new JButton("Restraurants");
        restraurants.setFont(new Font("Tahoma",Font.PLAIN,15));
        restraurants.setBounds(130,70,150,40);
        restraurants.addActionListener(this);
        add(restraurants);
        
        outingplaces = new JButton("Outing Places");
        outingplaces.setFont(new Font("Tahoma",Font.PLAIN,15));
        outingplaces.setBounds(130,120,150,40);
        outingplaces.addActionListener(this);
        add(outingplaces);
        
        shoping = new JButton("Shoping Malls");
        shoping.setFont(new Font("Tahoma",Font.PLAIN,15));
        shoping.setBounds(130,170,150,40);
        shoping.addActionListener(this);
        add(shoping);
        
        entertainment = new JButton("Movie Theatres");
        entertainment.setFont(new Font("Tahoma",Font.PLAIN,15));
        entertainment.setBounds(130,220,150,40);
        entertainment.addActionListener(this);
        add(entertainment);
        
        back = new JButton("Back");
        back.setFont(new Font("Tahoma",Font.PLAIN,15));
        back.setBounds(170,280,60,30);
        back.addActionListener(this);
        add(back);
        
        setBounds(150,150,400,350);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == restraurants){
            setVisible(false);
            new Restraurants();
        }else if(ae.getSource() == outingplaces){
            setVisible(false);
            new OutingPlaces();
        }else if(ae.getSource() == shoping){
            setVisible(false);
            new ShoppingMalls();
        }else if(ae.getSource() == entertainment){
            setVisible(false);
            new Entertainment();
        }else if(ae.getSource() == back){
            setVisible(false);
            new UserDashboard(username, password);
        }
    }
    
    public static void main(String[] args){
        
    }
}
