
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Date;
import java.awt.event.*;
/**
 *
 * @author raani
 */
public class AddCustomer extends JFrame implements ActionListener{
    
    JTextField tfidnumber,tfname,tfcountry,tfdeposit,tfbed,tftotalmember,tfusername,tfpassword;
    JComboBox comboidname;
    JRadioButton rbmale,rbfemale;
    Choice croom;
    JLabel checkintime;
    JButton add, back,check;
    
    AddCustomer(){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel text = new JLabel("NEW CUSTOMER FORM");
        text.setBounds(100,20,300,30);
        text.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(text);
        
        JLabel lblroom = new JLabel("Allocated Room Number ");
        lblroom.setBounds(35,60,170,20);
        lblroom.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblroom);
        
        
        croom = new Choice();
        
        try {
            Conn conn = new Conn();
            
            String query = "select * from room where availability = 'Available' ";
            
            ResultSet rs = conn.s.executeQuery(query);
            
            while(rs.next()){
                croom.add(rs.getString("roomnumber"));
                
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        
        croom.setBounds(200,60,100,25);
        add(croom);
        
        JLabel lblbedtype = new JLabel("Bed Type");
        lblbedtype.setBounds(35,100,170,20);
        lblbedtype.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblbedtype);
        
        tfbed = new JTextField();
        tfbed.setBounds(200,100,170,20);
        tfbed.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(tfbed);
        
        
        JLabel lblid = new JLabel("ID");
        lblid.setBounds(35,140,100,20);
        lblid.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblid);
        
        String idOption[] = { "Aadhar Card", "Passport","Driving License","Voter-id Card","Ration Card"};
        comboidname = new JComboBox(idOption);
        comboidname.setBounds(200,140,150,25);
        comboidname.setBackground(Color.WHITE);
        add(comboidname);
        
        JLabel lblidnumber = new JLabel("ID Number");
        lblidnumber.setBounds(35,180,100,20);
        lblidnumber.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblidnumber);
        
        tfidnumber = new JTextField();
        tfidnumber.setBounds(200,180,150,25);
        add(tfidnumber);
        
        JLabel lblname = new JLabel("Name");
        lblname.setBounds(35,220,100,20);
        lblname.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblname);
        
        tfname = new JTextField();
        tfname.setBounds(200,220,150,25);
        add(tfname);
        
        JLabel lblgender = new JLabel("GENDER");
        lblgender.setBounds(35,260,100,20);
        lblgender.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblgender);
        
        rbmale = new JRadioButton("MALE");
        rbmale.setBounds(200,260,70,30);
        rbmale.setFont(new Font("Tahoma",Font.PLAIN,15));
        rbmale.setBackground(Color.WHITE);
        add(rbmale);
        
        rbfemale = new JRadioButton("FEMALE");
        rbfemale.setBounds(280,260,90,30);
        rbfemale.setFont(new Font("Tahoma",Font.PLAIN,15));
        rbfemale.setBackground(Color.WHITE);
        add(rbfemale);
        
        JLabel lblcountry = new JLabel("Country");
        lblcountry.setBounds(35,300,100,20);
        lblcountry.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblcountry);
        
        tfcountry = new JTextField();
        tfcountry.setBounds(200,300,150,25);
        add(tfcountry);
        
        JLabel lbltotalmember = new JLabel("Total Member");
        lbltotalmember.setBounds(35,340,100,20);
        lbltotalmember.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lbltotalmember);
        
        tftotalmember = new JTextField();
        tftotalmember.setBounds(200,340,150,25);
        add(tftotalmember);
        
        JLabel lbltime = new JLabel("Checkin time");
        lbltime.setBounds(35,380,150,20);
        lbltime.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lbltime);
        
        Date date = new Date();
        
        checkintime = new JLabel("" + date);
        checkintime.setBounds(200,380,150,25);
        checkintime.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(checkintime);
        
        JLabel lbldeposit = new JLabel("Deposit");
        lbldeposit.setBounds(35,420,100,20);
        lbldeposit.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lbldeposit);
        
        tfdeposit = new JTextField();
        tfdeposit.setBounds(200,420,150,25);
        add(tfdeposit);
        
        JLabel lblusername = new JLabel("Username");
        lblusername.setBounds(35,460,100,20);
        lblusername.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblusername);
        
        tfusername = new JTextField();
        tfusername.setBounds(200,460,150,25);
        add(tfusername);
        
        JLabel lblpassword = new JLabel("Password");
        lblpassword.setBounds(35,500,100,20);
        lblpassword.setFont(new Font("Tahoma",Font.PLAIN,15));
        add(lblpassword);
        
        tfpassword = new JTextField();
        tfpassword.setBounds(200,500,150,25);
        add(tfpassword);
        
        check = new JButton("Check");
        check.setForeground(Color.BLACK);
        check.setBackground(Color.WHITE);
        check.setBounds(310,60,80,30);
        check.addActionListener(this);
        add(check);
        
        add = new JButton("Add Customer");
        add.setForeground(Color.BLACK);
        add.setBackground(Color.WHITE);
        add.setBounds(50,540,130,30);
        add.addActionListener(this);
        add(add);
        
        back = new JButton("Back");
        back.setForeground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.setBounds(200,540,130,30);
        back.addActionListener(this);
        add(back);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/l2.png"));
         Image i2 = i1.getImage().getScaledInstance(400,500,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(400,50,350,450);
        add(image);
        
        setBounds(350,200,800,600);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == check){
            String roomnum = croom.getSelectedItem();
            String query1 = "select * from room where roomnumber = '"+roomnum+"'";
            
            try {
                Conn c =new Conn();
                ResultSet rs = c.s.executeQuery(query1);
                
                while(rs.next()){
                    tfbed.setText(rs.getString("bed_type")); 
                }
            }catch (Exception e){
                e.printStackTrace();
            }
                
         }else if (ae.getSource() == add){
            
            String id_name = (String) comboidname.getSelectedItem();
            String id_number = tfidnumber.getText();
            String name = tfname.getText();
            
            String gender = null;
            if(rbmale.isSelected()){
                gender = "Male";
            } else {
                gender = "Female";
            }
            
            String country = tfcountry.getText();
            String room = croom.getSelectedItem();
            String checkin_time = checkintime.getText();
            String deposit = tfdeposit.getText();
            String bed_type = tfbed.getText();
            String total_members = tftotalmember.getText();
            String username = tfusername.getText();
            String password = tfpassword.getText();
            
            try {
                Conn conn = new Conn();
                
                String query = "insert into customer values('"+room+"','"+bed_type+"','"+id_name+"','"+id_number+"','"+name+"','"+gender+"','"+country+"','"+total_members+"','"+checkin_time+"','"+deposit+"')";
                
                String query2 = "insert into userlogin values('"+id_number+"','"+room+"','"+username+"','"+password+"')";
                
                String query3 = "update room set availability = 'Occupied' where roomnumber = '"+room+"'";
                
                conn.s.executeUpdate(query);
                conn.s.executeUpdate(query2);
                conn.s.executeUpdate(query3);
                
                JOptionPane.showMessageDialog(null,"New Customer added successfully");

                setVisible(false);
                
                new Reception();
                
            }catch (Exception e){
                e.printStackTrace();
            }
            
            
           
            
        }else if (ae.getSource() == back){
            setVisible(false);
                
            new Reception();
        }
    }
    
    public static void main(String[] args){
        new AddCustomer();
    }
}
