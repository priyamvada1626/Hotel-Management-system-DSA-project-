
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import net.proteanit.sql.*;

/**
 *
 * @author raani
 */
public class ShoppingMalls extends JFrame {
    
    ShoppingMalls(){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        setBounds(400,200,700,480);
        setVisible(true);
    }
    
    public static void main(String[] args){
        new ShoppingMalls();
    }
}
