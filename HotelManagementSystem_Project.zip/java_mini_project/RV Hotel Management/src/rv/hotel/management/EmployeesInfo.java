
package rv.hotel.management;

/**
 *
 * @author raani
 */


import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import net.proteanit.sql.*;

public class EmployeesInfo extends JFrame implements ActionListener{
    JTable table;
    JButton search,back;
    JComboBox job;
    
    EmployeesInfo(){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel lbljob = new JLabel("JOB");
        lbljob.setBounds(40,20,40,20);
        add(lbljob);
        
        job = new JComboBox(new String[]{"Front Desk Clerks","HouseKeeping","Security","IT staff","Human resource","Kitchen staff","Room Service","Accountant","Manager","Chef"});
        job.setBounds(100,20,150,25);
        job.setBackground(Color.WHITE);
        add(job);
        
        search = new JButton("Search");
        search.setForeground(Color.BLACK);
        search.setBackground(Color.WHITE);
        search.setBounds(270,20,120,30);
        search.addActionListener(this);
        add(search);
        
        JLabel l1=new JLabel("Employee_Name");
        l1.setBounds(60,60,100,20);
        add(l1);
        
        JLabel l2= new JLabel("Age");
        l2.setBounds(170,60,100,20);
        add(l2);
        
        JLabel l3= new JLabel("Gender");
        l3.setBounds(290,60,100,20);
        add(l3);
        
        JLabel l4= new JLabel("Job");
        l4.setBounds(410,60,100,20);
        add(l4);
        
        JLabel l5= new JLabel("Salary");
        l5.setBounds(540,60,100,20);
        add(l5);
        
        JLabel l6= new JLabel("Phone_NO");
        l6.setBounds(670,60,100,20);
        add(l6);
        
        JLabel l7= new JLabel("Email_ID");
        l7.setBounds(790,60,100,20);
        add(l7);
        
        JLabel l8= new JLabel("Aadhar_NO");
        l8.setBounds(910,60,100,20);
        add(l8);
        
        table= new JTable();
        table.setBounds(0,80,1000,400);
        table.setBackground(Color.PINK);
        add(table);
        
        try{
            Conn c =new Conn();
            ResultSet rs= c.s.executeQuery("select * from employee");
            table.setModel(DbUtils.resultSetToTableModel(rs)); 
        }catch(Exception e){
            e.printStackTrace();
        }
        
        table.setShowGrid(true);
        table.setGridColor(Color.BLACK);
        
        back = new JButton("Back");
        back.setForeground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.setBounds(420,500,120,30);
        back.addActionListener(this);
        add(back);
        
        
        setBounds(300,200,1000,600);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == search){
            try {
            String query = "select * from employee where job = '"+job.getSelectedItem()+"'";
            
            Conn c = new Conn();
            ResultSet rs;
            
            rs = c.s.executeQuery(query);
            
            table.setModel(DbUtils.resultSetToTableModel(rs));
            }catch(Exception e){
                e.printStackTrace();
            }
            
        }else if(ae.getSource() == back){
        setVisible(false);
        new Reception();
        }
    }
    
    public static void main(String[] args){
        new EmployeesInfo();
    }
    
}
