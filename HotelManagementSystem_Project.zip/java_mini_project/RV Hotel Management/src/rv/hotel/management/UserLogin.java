
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

/**
 *
 * @author raani
 */
public class UserLogin extends JFrame implements ActionListener{
    
    JTextField username;
    JPasswordField pass;
    JButton login,cancel,adminlogin;
    //public String user,passs;
    
    
    UserLogin() {
        getContentPane().setBackground(Color.PINK);
        
        setLayout(null);
        
        username = new JTextField();
       username.setBounds(150, 20, 150, 35);
       add(username);
                
                
        JLabel user = new JLabel("username");
        user.setBounds(40,20,100,35);
        add(user);
        
        pass = new JPasswordField();
       pass.setBounds(150, 70, 150, 35);
       add(pass);
                
        
        JLabel password = new JLabel("password");
        password.setBounds(40,70,100,35);
        add(password);
        
        login = new JButton("Login");
        login.setBounds(40,150,120,40);
        login.setBackground(Color.WHITE);
        login.setForeground(Color.BLACK);
        login.addActionListener(this);
        add(login);
        
        cancel = new JButton("cancel");
        cancel.setBounds(180,150,120,40);
        cancel.setBackground(Color.WHITE);
        cancel.setForeground(Color.BLACK);
        cancel.addActionListener(this);
        add(cancel);
        
        adminlogin = new JButton("Admin login");
        adminlogin.setBounds(120,200,120,20);
        adminlogin.setBackground(Color.WHITE);
        adminlogin.setForeground(Color.BLACK);
        adminlogin.addActionListener(this);
        add(adminlogin);
        
        ImageIcon i1 =new  ImageIcon(ClassLoader.getSystemResource("icons/l9.jpg"));
        Image i2 = i1.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350,30,150,150);
        add(image);
       
        
        setBounds(500,200,600,300);
        setVisible(true);
        
    }
    
    public void actionPerformed(ActionEvent ae){
        if (ae.getSource() == login){
          String  user = username.getText();
          String  passs = new String(pass.getText());
            
            try{
                Conn c = new Conn();
                
                String query = "select * from userlogin where username = '" + user + "' and  password = '" + passs +"' ";
                
                ResultSet rs = c.s.executeQuery(query);
                
                if(rs.next()){
                    setVisible(false);
                    //new UserDashboard();
                    new UserDashboard(user,passs);
                }else{
                    JOptionPane.showMessageDialog(null,"Invalid username or password");
                    setVisible(false);
                }
            } catch (Exception e){
               e.printStackTrace(); 
            }
        }else if(ae.getSource() == adminlogin){
            setVisible(false);
            new Login();
        }else if (ae.getSource() == cancel){
            setVisible(false);
        }
        
    }
    
    public static void main(String[] args) {
        new UserLogin();
    }
    
}
