
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;
/**
 *
 * @author raani
 */
public class Checkout extends JFrame implements ActionListener{
    
    Choice ccustomerid;
    JLabel lblroomnumber,lblcheckintime,lblcheckouttime;
    JButton back,checkout;
    
    Checkout() {
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel text = new JLabel("Checkout");
        text.setBounds(100,20,100,30);
        text.setForeground(Color.BLUE);
        text.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(text);
        
        JLabel lblid = new JLabel("Customer ID");
        lblid.setBounds(30,80,100,30);
        add(lblid);
        
        ccustomerid = new Choice();
        ccustomerid.setBounds(150,80,150,25);
        add(ccustomerid);
        
        JLabel lblroom = new JLabel("Room Number");
        lblroom.setBounds(30,130,200,30);
        add(lblroom);
        
        lblroomnumber = new JLabel();
        lblroomnumber.setBounds(150, 130, 200, 30);
        add(lblroomnumber);
        
        JLabel lblcheckin = new JLabel("Checkin Time"); //local declaration
        lblcheckin.setBounds(30,180,200,30);
        add(lblcheckin);
        
        lblcheckintime = new JLabel(); //global declaration
        lblcheckintime.setBounds(150, 180, 200, 30);
        add(lblcheckintime);
        
        JLabel lblcheckout = new JLabel("Checkout Time"); //local declaration
        lblcheckout.setBounds(30,230,200,30);
        add(lblcheckout);
        
        Date date = new Date();
        
        lblcheckouttime = new JLabel(" " + date); //global declaration
        lblcheckouttime.setBounds(150, 230, 200, 30);
        add(lblcheckouttime);
        
        checkout = new JButton("Checkout");
        checkout.setForeground(Color.BLACK);
        checkout.setBackground(Color.WHITE);
        checkout.setBounds(30,280,120,30);
        checkout.addActionListener(this);
        add(checkout);
        
        back = new JButton("Back");
        back.setForeground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.setBounds(170,280,120,30);
        back.addActionListener(this);
        add(back);
        
        
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from customer");
            
            while(rs.next()){
                 ccustomerid.add(rs.getString("id_number"));
                 lblroomnumber.setText(rs.getString("room_allocated"));
                 lblcheckintime.setText(rs.getString("checkin_time"));
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/l6.jpg"));
        Image i2 = i1.getImage().getScaledInstance(400,250,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(350,50,400,250);
        add(image);
        
        setBounds(300,200,800,400);
        setVisible(true);
        
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == checkout){
            String query1 = "delete from customer where id_number = '"+ccustomerid.getSelectedItem()+"'";
            String query2 ="delete from userlogin where id_number = '"+ccustomerid.getSelectedItem()+"'";
            String query3 = "update room set availability = 'Available' where roomnumber = '"+lblroomnumber.getText()+"' ";
            try {
                Conn c = new Conn();
                
                c.s.executeUpdate(query1);
                c.s.executeUpdate(query2);
                c.s.executeUpdate(query3);
                
                JOptionPane.showMessageDialog(null,"Checkout done");
                
                setVisible(false);
                new Reception();
                
            }catch(Exception e){
                e.printStackTrace();
            }
        }else if(ae.getSource() == back){
            setVisible(false);
            new Reception();
        }
    }
    
    public static void main(String[] args){
        new Checkout();
    }
}
