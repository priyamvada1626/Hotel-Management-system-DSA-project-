package rv.hotel.management;

/**
 *
 * @author raani
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public  class RVHotelManagement extends JFrame implements ActionListener{

    RVHotelManagement(){
       //  setSize(1300,500);
       //  setLocation(100,100);
       setBounds(100,100,1300,500);
        setLayout(null);
        
        ImageIcon i1 =new  ImageIcon(ClassLoader.getSystemResource("icons/l11.jpg"));
        JLabel image = new JLabel(i1);
        image.setBounds(0,0,1300,500); // Location of x, Location of , length, bredth 
        add(image);
        
        JLabel text = new JLabel("RV HOTEL MANAGEMENT");
        text.setBounds(20,430,1000,35);
        text.setForeground(Color.WHITE);
        text.setFont(new Font("serif",Font.PLAIN, 50));
        image.add(text);
        
        JButton next = new JButton("next");
        next.setBounds(1100, 400, 150, 40);
        next.setBackground(Color.WHITE);
        next.setForeground(Color.BLACK);
        
        next.setFont(new Font("serif",Font.PLAIN, 20));
        image.add(next);
        next.addActionListener(this);        
        
        setVisible(true);
        
        
        while(true){  // infinite loop
            text.setVisible(false);
            try {
                Thread.sleep(400);
            } catch (Exception e) {
                e.printStackTrace();
            }
            text.setVisible(true);
            try {
                Thread.sleep(600);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        
    }
    
    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Login();
        
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        new RVHotelManagement();
    }
    
}
