
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author raani
 */
public class Reception extends JFrame implements ActionListener {
    
    JButton dashboard,newcustomer,rooms,department,allemployee,customerinfo,managerinfo,checkout,updatependingstatus,roomstatus,pickup,searchroom,logout,isbox;
    
    Reception(){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel heading = new JLabel("Reception");
        heading.setBounds(50,3,200,30);
        heading.setFont(new Font("Tahoma",Font.BOLD,18));
        add(heading);
        
        newcustomer = new JButton("New Customer Form");
        newcustomer.setBounds(10,30,200,30);
        newcustomer.setBackground(Color.WHITE);
        newcustomer.setForeground(Color.BLACK);
        newcustomer.addActionListener(this);
        add(newcustomer);
        
        rooms = new JButton("Rooms");
        rooms.setBounds(10,70,200,30);
        rooms.setBackground(Color.WHITE);
        rooms.setForeground(Color.BLACK);
        rooms.addActionListener(this);
        add(rooms);
        
        department = new JButton("Department");
        department.setBounds(10,110,200,30);
        department.setBackground(Color.WHITE);
        department.setForeground(Color.BLACK);
        department.addActionListener(this);
        add(department);
        
        allemployee = new JButton("All Employees");
        allemployee.setBounds(10,150,200,30);
        allemployee.setBackground(Color.WHITE);
        allemployee.setForeground(Color.BLACK);
        allemployee.addActionListener(this);
        add(allemployee);
        
        customerinfo = new JButton("Customers Info");
        customerinfo.setBounds(10,190,200,30);
        customerinfo.setBackground(Color.WHITE);
        customerinfo.setForeground(Color.BLACK);
        customerinfo.addActionListener(this);
        add(customerinfo);
        
        checkout = new JButton("Checkout");
        checkout.setBounds(10,230,200,30);
        checkout.setBackground(Color.WHITE);
        checkout.setForeground(Color.BLACK);
        checkout.addActionListener(this);
        add(checkout);
        
        updatependingstatus = new JButton("Update Pending Status");
        updatependingstatus.setBounds(10,270,200,30);
        updatependingstatus.setBackground(Color.WHITE);
        updatependingstatus.setForeground(Color.BLACK);
        updatependingstatus.addActionListener(this);
        add(updatependingstatus);
        
        roomstatus = new JButton("Update Room Status");
        roomstatus.setBounds(10,310,200,30);
        roomstatus.setBackground(Color.WHITE);
        roomstatus.setForeground(Color.BLACK);
        roomstatus.addActionListener(this);
        add(roomstatus);
        
        pickup = new JButton("Pickup Service");
        pickup.setBounds(10,350,200,30);
        pickup.setBackground(Color.WHITE);
        pickup.setForeground(Color.BLACK);
        pickup.addActionListener(this);
        add(pickup);
        
        searchroom = new JButton("Search Room");
        searchroom.setBounds(10,390,200,30);
        searchroom.setBackground(Color.WHITE);
        searchroom.setForeground(Color.BLACK);
        searchroom.addActionListener(this);
        add(searchroom);
        
        logout = new JButton("Logout");
        logout.setBounds(10,430,200,30);
        logout.setBackground(Color.WHITE);
        logout.setForeground(Color.BLACK);
        logout.addActionListener(this);
        add(logout);
        
        dashboard = new JButton("Dashboard");
        dashboard.setBounds(10,470,200,30);
        dashboard.setBackground(Color.WHITE);
        dashboard.setForeground(Color.BLACK);
        dashboard.addActionListener(this);
        add(dashboard);
        
        isbox = new JButton("Issue Box");
        isbox.setBounds(10,510,200,30);
        isbox.setBackground(Color.WHITE);
        isbox.setForeground(Color.BLACK);
        isbox.addActionListener(this);
        add(isbox);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/l7.png"));
        JLabel image = new JLabel(i1);
        image.setBounds(250,30,500,510);
        add(image);
        
        setBounds(350,200,800,610);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if (ae.getActionCommand().equals("New Customer Form")){
            setVisible(false);
            new AddCustomer();
        }else if(ae.getSource() == rooms){
            setVisible(false);
            new Room();
        }else if(ae.getSource() == department){
            setVisible(false);
            new Department();
        }else if(ae.getSource() == allemployee){
            setVisible(false);
            new EmployeesInfo();
        }else if(ae.getSource() == customerinfo){
            setVisible(false);
            new CustomerInfo();
        }else if(ae.getSource() == searchroom){
            setVisible(false);
            new SearchRoom();
        }else if(ae.getSource() == updatependingstatus){
            setVisible(false);
            new UpdateCheck();
        }else if(ae.getSource() == roomstatus){
            setVisible(false);
            new UpdateRoom();
        }else if(ae.getSource() == pickup){
            setVisible(false);
            new PickUpService();
        }else if(ae.getSource() == checkout){
            setVisible(false);
            new Checkout();
        }else if(ae.getSource() == logout){
            setVisible(false);
            new Login();
        }else if(ae.getSource() == dashboard){
            setVisible(false);
            new Dashboard();
        }else if(ae.getSource() == isbox){
            setVisible(false);
            new RIssueBox();
        }
            
    }
    
    public static void main(String[] args){
        new Reception();
    }
    
}
