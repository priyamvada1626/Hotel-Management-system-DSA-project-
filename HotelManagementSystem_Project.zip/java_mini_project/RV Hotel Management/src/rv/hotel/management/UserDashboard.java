
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


/**
 *
 * @author raani
 */
public class UserDashboard extends JFrame implements ActionListener {
    
    JLabel lblusername,lblidname,lblidnumber,lblroomnumber,lblbedtype,lbltotalmembers,lbltotalprice,lbldeposit,lblpendingamount,lblcheckintime;
    JButton logout,nearby,ibox,contact,restraurantmenu;
    private String username;
    private String password;
    
    UserDashboard(String usern, String passw) {
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel heading = new JLabel("Personal Details");
        heading.setBounds(100,20,200,30);
        heading.setFont(new Font("Tahoma",Font.BOLD,18));
        add(heading);
        
        JLabel lblname = new JLabel("User Name");
        lblname.setBounds(30, 70, 100, 30);
        add(lblname);
        
        lblusername =new JLabel();
        lblusername.setBounds(150,70,100,30);
        add(lblusername);
        
        JLabel lblid = new JLabel("ID");
        lblid.setBounds(30, 110, 100, 30);
        add(lblid);
        
        lblidname =new JLabel();
        lblidname.setBounds(150,110,100,30);
        add(lblidname);
        
        JLabel lblidnu = new JLabel("ID Number");
        lblidnu.setBounds(30, 150, 100, 30);
        add(lblidnu);
        
        lblidnumber =new JLabel();
        lblidnumber.setBounds(150,150,100,30);
        add(lblidnumber);
        
        JLabel lblroomnu = new JLabel("Room Number");
        lblroomnu.setBounds(30, 190, 100, 30);
        add(lblroomnu);
        
        lblroomnumber =new JLabel();
        lblroomnumber.setBounds(150,190,100,30);
        add(lblroomnumber);
        
        JLabel lblbtype = new JLabel("Bed Type");
        lblbtype.setBounds(30, 230, 100, 30);
        add(lblbtype);
        
        lblbedtype =new JLabel();
        lblbedtype.setBounds(150,230,100,30);
        add(lblbedtype);
        
        JLabel lblmember = new JLabel("Total Members");
        lblmember.setBounds(30, 270, 100, 30);
        add(lblmember);
        
        lbltotalmembers =new JLabel();
        lbltotalmembers.setBounds(150,270,100,30);
        add(lbltotalmembers);
        
        JLabel lblprice = new JLabel("Total Price");
        lblprice.setBounds(30, 310, 100, 30);
        add(lblprice);
        
        lbltotalprice =new JLabel();
        lbltotalprice.setBounds(150,310,100,30);
        add(lbltotalprice);
        
        JLabel lbldamount = new JLabel("Deposit");
        lbldamount.setBounds(30, 350, 100, 30);
        add(lbldamount);
        
        lbldeposit =new JLabel();
        lbldeposit.setBounds(150,350,100,30);
        add(lbldeposit);
        
        JLabel lblpamount = new JLabel("Pending Amount");
        lblpamount.setBounds(30, 390, 130, 30);
        add(lblpamount);
        
        lblpendingamount =new JLabel();
        lblpendingamount.setBounds(150,390,100,30);
        add(lblpendingamount);
        
        JLabel lblcheck = new JLabel("Checkin Time");
        lblcheck.setBounds(30, 430, 130, 30);
        add(lblcheck);
        
        lblcheckintime =new JLabel();
        lblcheckintime.setBounds(150,430,150,30);
        add(lblcheckintime);
        
        this.username = usern;
        this.password = passw;
        
         try{
            Conn c = new Conn();
            
            ResultSet rs = c.s.executeQuery("select * from userlogin where username = '"+usern+"' and password = '"+passw+"'");
            
            while(rs.next()){
                lblidnumber.setText(rs.getString("id_number"));
                lblroomnumber.setText(rs.getString("room_allocated"));
            
            String id_num = rs.getString("id_number");
            String room_num = rs.getString("room_allocated");
            
            ResultSet rs2 = c.s.executeQuery("select * from customer where id_number = '"+id_num+"' ");
            
            while(rs2.next()){
                lblusername.setText(rs2.getString("name"));
                lblidname.setText(rs2.getString("id_name"));
                lblbedtype.setText(rs2.getString("bed_type"));
                lbltotalmembers.setText(rs2.getString("total_members"));
                lbldeposit.setText(rs2.getString("deposit"));
                lblcheckintime.setText(rs2.getString("checkin_time"));
                
             String depo = rs2.getString("deposit");
            
            ResultSet rs3 = c.s.executeQuery("select * from room where roomnumber = '"+room_num+"'");
            
            while(rs3.next()){
                lbltotalprice.setText(rs3.getString("price"));
                String price = rs3.getString("price");
                    int amounttoPay = Integer.parseInt(price) - Integer.parseInt(depo);
                    lblpendingamount.setText(" " + amounttoPay);
            }
            
            }
          } 
       }catch(Exception e){
            e.printStackTrace();
        }
         
        nearby = new JButton("Near By Locations");
        nearby.setForeground(Color.BLACK);
        nearby.setBackground(Color.WHITE);
        nearby.setBounds(450,100,150,40);
        nearby.addActionListener(this);
        add(nearby);
        
        ibox = new JButton("Issue Box");
        ibox.setForeground(Color.BLACK);
        ibox.setBackground(Color.WHITE);
        ibox.setBounds(450,200,150,40);
        ibox.addActionListener(this);
        add(ibox);
        
        contact = new JButton("Contact List");
        contact.setForeground(Color.BLACK);
        contact.setBackground(Color.WHITE);
        contact.setBounds(450,300,150,40);
        contact.addActionListener(this);
        add(contact);
        
        restraurantmenu = new JButton("Food and Beverages");
        restraurantmenu.setForeground(Color.BLACK);
        restraurantmenu.setBackground(Color.WHITE);
        restraurantmenu.setBounds(450,400,150,40);
        restraurantmenu.addActionListener(this);
        add(restraurantmenu);
        
        logout = new JButton("Logout");
        logout.setForeground(Color.BLACK);
        logout.setBackground(Color.WHITE);
        logout.setBounds(300,500,150,40);
        logout.addActionListener(this);
        add(logout);
        
        
        
        setBounds(350,200,800,600);
        setVisible(true);
        
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == logout){
            setVisible(false);
            new UserLogin();
        }else if(ae.getSource() == contact){
            setVisible(false);
            new ContactList(username, password);
        }else if(ae.getSource() == restraurantmenu){
            setVisible(false);
            new FoodAndBeverages(username, password);
        }else if(ae.getSource() == nearby){
            setVisible(false);
            new NearBy(username, password);
        }else if(ae.getSource() == ibox){
            setVisible(false);
            new IssueBox(username, password);
        }
    }
    
    public static void main(String[] args){
        
    }
}
