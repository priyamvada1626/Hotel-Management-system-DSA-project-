
package rv.hotel.management;

/**
 *
 * @author raani
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddDrivers extends JFrame implements ActionListener{
    
    JTextField tfname,tfage,tfcarcompany,tfcarmodel,tflocation;
    JComboBox gendercombo,availablecombo;
    JButton add, cancel;
    
    AddDrivers(){
      
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel heading = new JLabel("Add Drivers");
        heading.setBounds(150,10,200,30);
        heading.setFont(new Font("Tahoma",Font.BOLD,18));
        add(heading);
        
        JLabel lblname = new JLabel("Name");
        lblname.setBounds(60,70,120,30);
        lblname.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblname);
        
        tfname = new JTextField();
        tfname.setBounds(200,70,150,30);
        add(tfname);
        
        JLabel lblage = new JLabel("Age");
        lblage.setBounds(60,110,120,30);
        lblage.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblage);
        
        tfage = new JTextField();
        tfage.setBounds(200,110,150,30);
        add(tfage);
        
         JLabel lblgender = new JLabel("Gender");
        lblgender.setBounds(60,150,120,30);
        lblgender.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblgender);
        
        String genderOption[] = { "Male", "Femele"};
        gendercombo = new JComboBox(genderOption);
        gendercombo.setBounds(200,150,150,30);
        gendercombo.setBackground(Color.WHITE);
        add(gendercombo);
        
        
        JLabel lblcarcompany = new JLabel("Car Company");
        lblcarcompany.setBounds(60,190,120,30);
        lblcarcompany.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblcarcompany);
        
        tfcarcompany = new JTextField();
        tfcarcompany.setBounds(200,190,150,30);
        add(tfcarcompany);
        
        JLabel lblcarmodel = new JLabel("Car Model");
        lblcarmodel.setBounds(60,230,120,30);
        lblcarmodel.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblcarmodel);
        
        tfcarmodel = new JTextField();
        tfcarmodel.setBounds(200,230,150,30);
        add(tfcarmodel);
        
        JLabel lblavailable = new JLabel("Availaibility");
        lblavailable.setBounds(60,270,120,30);
        lblavailable.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblavailable);
        
        String driverOption[] = { "Avaialble", "Busy"};
        availablecombo = new JComboBox(driverOption);
        availablecombo.setBounds(200,270,150,30);
        availablecombo.setBackground(Color.WHITE);
        add(availablecombo);
        
        JLabel lbllocation = new JLabel("Location");
        lbllocation.setBounds(60,310,120,30);
        lbllocation.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lbllocation);
        
        tflocation = new JTextField();
        tflocation.setBounds(200,310,150,30);
        add(tflocation);
        
        add = new JButton("Add Driver");
        add.setForeground(Color.BLACK);
        add.setBackground(Color.WHITE);
        add.setBounds(60,370,130,30);
        add.addActionListener(this);
        add(add);
        
         cancel = new JButton("Cancel");
        cancel.setForeground(Color.BLACK);
        cancel.setBackground(Color.WHITE);
        cancel.setBounds(220,370,130,30);
        cancel.addActionListener(this);
        add(cancel);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/l3.jpg"));
         Image i2 = i1.getImage().getScaledInstance(500,300,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(400,30,500,350);
        add(image);
        
        setBounds(300,200,980,470);
        setVisible(true);
        
    }
    
     public void actionPerformed(ActionEvent ae){
         if (ae.getSource() == add ){
             String name = tfname.getText();
             String age = tfage.getText();
             String gender = (String) gendercombo.getSelectedItem();
             String car_company = tfcarcompany.getText();
             String car_model = tfcarmodel.getText();
             String availability = (String) availablecombo.getSelectedItem();
             String location = tflocation.getText();
             
             try {
                 Conn conn =new Conn();
                 
                 String query = "insert into driver values('"+name+"','"+age+"','"+gender+"','"+car_company+"','"+car_model+"','"+availability+"','"+location+"')";
                 
                 conn.s.executeUpdate(query);
                 
                 JOptionPane.showMessageDialog(null,"New Driver added successfully");
            
                 setVisible(false);
                 new Dashboard();
                 
             }catch (Exception e){
                 e.printStackTrace();
             }
             
         }else {
             setVisible(false);
         }
     }
    
     public static void main(String[] args){
        new AddDrivers();
    }
    
}
