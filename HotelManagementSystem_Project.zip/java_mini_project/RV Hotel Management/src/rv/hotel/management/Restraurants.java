
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import net.proteanit.sql.*;

/**
 *
 * @author raani
 */
public class Restraurants extends JFrame{
    
    Restraurants(){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel heading = new JLabel("Restraurants");
        heading.setFont(new Font("Tahoma",Font.PLAIN,20));
        heading.setBounds(230,20,200,20);
        add(heading);
        
        
        
        setBounds(400,200,700,480);
        setVisible(true);
    }
    
    public static void main(String[] args){
        new Restraurants();
    }
    
}
