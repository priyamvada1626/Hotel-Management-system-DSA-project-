
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
import net.proteanit.sql.*;


/**
 *
 * @author raani
 */
public class RIssueBox extends JFrame  implements ActionListener{
    
    JButton back,update,check,search;
    JTable table;
    Choice croom,cissue;
    
    RIssueBox(){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel heading = new JLabel("Issue Box");
        heading.setFont(new Font("Tahoma",Font.PLAIN,20));
        heading.setBounds(260,20,200,20);
        add(heading);
        
        JLabel lblroom = new JLabel("Room number");
        lblroom.setBounds(30,80,100,20);
        add(lblroom);
        
        croom = new Choice();
        croom.setBounds(140,80,150,25);
        add(croom);
        
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from issuebox");
            
            while(rs.next()){
                 croom.add(rs.getString("roomnumber"));
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
        
        search = new JButton("Search");
        search.setForeground(Color.BLACK);
        search.setBackground(Color.WHITE);
        search.setBounds(300,80,50,20);
        search.addActionListener(this);
        add(search);
        
        JLabel lblrooom = new JLabel("Room number");
        lblrooom.setBounds(60,130,100,20);
        add(lblrooom);
        
        JLabel lblissuee = new JLabel("Issue");
        lblissuee.setBounds(300,130,100,20);
        add(lblissuee);
        
        JLabel lblstatus = new JLabel("Status");
        lblstatus.setBounds(520,130,100,20);
        add(lblstatus);
        
        table = new JTable();
        table.setBounds(0, 160, 700, 210);
        table.setBackground(Color.PINK);
        table.setShowGrid(true);
        table.setGridColor(Color.BLACK);
        add(table);
        
        try{
            Conn c =new Conn();
            ResultSet rs= c.s.executeQuery("select * from issuebox");
            table.setModel(DbUtils.resultSetToTableModel(rs)); 
        }catch(Exception e){
            e.printStackTrace();
        }
        
        update = new JButton("Update");
        update.setForeground(Color.BLACK);
        update.setBackground(Color.WHITE);
        update.setBounds(240,420,80,25);
        update.addActionListener(this);
        add(update);
        
        back = new JButton("Back");
        back.setForeground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.setBounds(340,420,80,25);
        back.addActionListener(this);
        add(back);
        
        setBounds(400,200,700,500);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == search){
            try {
                Conn c = new Conn();
                
                String roomnum = croom.getSelectedItem();
            
                String query = "select * from issuebox where roomnumber = '"+roomnum+"'";
                
                ResultSet rs3;
                
                rs3 = c.s.executeQuery(query);
                
                table.setModel(DbUtils.resultSetToTableModel(rs3));
                
            }catch(Exception e){
                e.printStackTrace();
            }
        }else if(ae.getSource() == update){
            try {
                Conn c = new Conn();
                
                String roomnum = croom.getSelectedItem();
                
                String query1 = "delete from issuebox where roomnumber = '"+roomnum+"'";
                
                c.s.executeUpdate(query1);
                
                ResultSet rs4;
                    
                String query2 = "select * from issuebox";
                
                rs4 = c.s.executeQuery(query2);
                
                table.setModel(DbUtils.resultSetToTableModel(rs4));
                
                JOptionPane.showMessageDialog(null, "Data Updated Successfully");
                
            }catch(Exception e){
                e.printStackTrace();
            }
        }else if(ae.getSource() == back){
            setVisible(false);
            new Reception();
        }
    }
    
    public static void main(String[] args){
        new RIssueBox();
    }
}
