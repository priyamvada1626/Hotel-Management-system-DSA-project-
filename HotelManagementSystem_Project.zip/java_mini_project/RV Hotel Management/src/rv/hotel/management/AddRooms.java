
package rv.hotel.management;

/**
 *
 * @author raani
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddRooms extends JFrame implements ActionListener{
    
    JTextField tfroomno,tfprice;
    JComboBox availablecombo,cleancombo,typecombo;
    JButton add, cancel;
    
    AddRooms(){
      
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        JLabel heading = new JLabel("Add Rooms");
        heading.setBounds(150,20,200,30);
        heading.setFont(new Font("Tahoma",Font.BOLD,18));
        add(heading);
        
        JLabel lblroomno = new JLabel("Room Number");
        lblroomno.setBounds(60,80,120,30);
        lblroomno.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblroomno);
        
        tfroomno = new JTextField();
        tfroomno.setBounds(200,80,150,30);
        add(tfroomno);
        
        JLabel lblavailable = new JLabel("Availability");
        lblavailable.setBounds(60,130,120,30);
        lblavailable.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblavailable);
        
        String availableOption[] = { "Available", "Occupied"};
        availablecombo = new JComboBox(availableOption);
        availablecombo.setBounds(200,130,150,30);
        availablecombo.setBackground(Color.WHITE);
        add(availablecombo);
        
         JLabel lblclean = new JLabel("Cleaning Status");
        lblclean.setBounds(60,180,120,30);
        lblclean.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblclean);
        
        String cleanOption[] = { "Clean", "Dirty"};
        cleancombo = new JComboBox(cleanOption);
        cleancombo.setBounds(200,180,150,30);
        cleancombo.setBackground(Color.WHITE);
        add(cleancombo);
        
        
        JLabel lblprice = new JLabel(" Price");
        lblprice.setBounds(60,230,120,30);
        lblprice.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lblprice);
        
        tfprice = new JTextField();
        tfprice.setBounds(200,230,150,30);
        add(tfprice);
        
        JLabel lbltype = new JLabel("Bed Type");
        lbltype.setBounds(60,280,120,30);
        lbltype.setFont(new Font("Tahoma",Font.PLAIN,14));
        add(lbltype);
        
        String typeOption[] = { "Single Bed", "Double Bed"};
        typecombo = new JComboBox(typeOption);
        typecombo.setBounds(200,280,150,30);
        typecombo.setBackground(Color.WHITE);
        add(typecombo);
        
         add = new JButton("Add Room");
        add.setForeground(Color.BLACK);
        add.setBackground(Color.WHITE);
        add.setBounds(60,350,130,30);
        add.addActionListener(this);
        add(add);
        
         cancel = new JButton("Cancel");
        cancel.setForeground(Color.BLACK);
        cancel.setBackground(Color.WHITE);
        cancel.setBounds(220,350,130,30);
        cancel.addActionListener(this);
        add(cancel);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/l5.png"));
         Image i2 = i1.getImage().getScaledInstance(450,450,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(400,30,500,350);
        add(image);
        
        setBounds(330,200,940,470);
        setVisible(true);
        
    }
    
     public void actionPerformed(ActionEvent ae){
         if (ae.getSource() == add ){
             String roomnumber = tfroomno.getText();
             String availability = (String) availablecombo.getSelectedItem();
             String cleaning_status = (String) cleancombo.getSelectedItem();
             String price = tfprice.getText();
             String bed_type = (String) typecombo.getSelectedItem();
             
             try {
                 Conn conn =new Conn();
                 
                 String query = "insert into room values('"+roomnumber+"','"+availability+"','"+cleaning_status+"','"+price+"','"+bed_type+"')";
                 
                 conn.s.executeUpdate(query);
                 
                 JOptionPane.showMessageDialog(null,"Room added successfully");
            
                 setVisible(false);
                 new Dashboard();
                 
             }catch (Exception e){
                 e.printStackTrace();
             }
             
         }else {
             setVisible(false);
             new Dashboard();
         }
     }
    
     public static void main(String[] args){
        new AddRooms();
    }
    
}
