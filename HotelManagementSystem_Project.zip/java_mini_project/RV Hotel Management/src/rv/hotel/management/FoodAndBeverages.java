
package rv.hotel.management;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.*;
/**
 *
 * @author raani
 */
public class FoodAndBeverages extends JFrame implements ActionListener{
    JTable table,table2,table3;
    JButton back;
    private String username;
    private String password;
    
    FoodAndBeverages(String usern, String passw){
        
        getContentPane().setBackground(Color.PINK);
        setLayout(null);
        
        this.username = usern;
        this.password = passw;
        
        JLabel heading = new JLabel("Food and Beverages");
        heading.setFont(new Font("Tahoma",Font.PLAIN,20));
        heading.setBounds(100,10,200,30);
        add(heading);
        
        JLabel phoneno = new JLabel("Ph_no 9822510622");
        phoneno.setBounds(120,30,200,30);
        add(phoneno);
        
        JLabel morning = new JLabel("Morning/Evening-Breakfast");
        morning.setBounds(30,60,200,30);
        add(morning);
        
        JLabel l1=new JLabel("Dish_name");
        l1.setBounds(40,90,100,20);
        add(l1);
        
        JLabel l2=new JLabel("Price");
        l2.setBounds(300,90,30,20);
        add(l2);
        
        table = new JTable();
        table.setBounds(0,120,550,120);
        table.setBackground(Color.PINK);
        add(table);
        
        try {
            Conn c = new Conn();
            
            String query = "select * from morning_evening_breakfast";
            
            ResultSet rs;
            
            rs = c.s.executeQuery(query);
            
            table.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e){
            e.printStackTrace();
        }
        
        table.setShowGrid(true);
        table.setGridColor(Color.BLACK);
        
        
        JLabel lunch = new JLabel("Lunch");
        lunch.setBounds(30,260,150,30);
        add(lunch);
        
        JLabel l3=new JLabel("Dish_name");
        l3.setBounds(40,290,100,20);
        add(l3);
        
        JLabel l4=new JLabel("Price");
        l4.setBounds(300,290,30,20);
        add(l4);
        
        table2 = new JTable();
        table2.setBounds(0,320,550,150);
        table2.setBackground(Color.PINK);
        add(table2);
        
        try {
            Conn c = new Conn();
            
            String query = "select * from lunch";
            
            ResultSet rs;
            
            rs = c.s.executeQuery(query);
            
            table2.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e){
            e.printStackTrace();
        }
        
        table2.setShowGrid(true);
        table2.setGridColor(Color.BLACK);
        
        JLabel dinner = new JLabel("Dinner");
        dinner.setBounds(30,490,150,30);
        add(dinner);
        
        JLabel l5=new JLabel("Dish_name");
        l5.setBounds(40,520,100,20);
        add(l5);
        
        JLabel l6=new JLabel("Price");
        l6.setBounds(300,520,30,20);
        add(l6);
        
        table3 = new JTable();
        table3.setBounds(0,550,550,180);
        table3.setBackground(Color.PINK);
        add(table3);
        
        try {
            Conn c = new Conn();
            
            String query = "select * from dinner";
            
            ResultSet rs;
            
            rs = c.s.executeQuery(query);
            
            table3.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e){
            e.printStackTrace();
        }
        
        table3.setShowGrid(true);
        table3.setGridColor(Color.BLACK);
        
        back = new JButton("Back");
        back.setForeground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.setBounds(190,730,120,30);
        back.addActionListener(this);
        add(back);
        
        setBounds(300,200,550,800);
        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource() == back){
            setVisible(false);
            new UserDashboard(username, password);
        }
    }
    
    public static void main(String[] args){
        //new FoodAndBeverages();
    }
}
